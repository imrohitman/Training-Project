
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/renewal")
public class renewal extends HttpServlet {

	Statement st = null;
	Connection con = null;
	ResultSet rs;

	public void init() {
		System.out.println("init");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "123456789");

		} catch (Exception ae) {
		}
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<meta http-equiv=\"content-type\" content=\"text/html;charset=UTF-8\" />\r\n"
			+ "    <meta charset=\"utf-8\" />\r\n" + "    <title>Eco-Insurance</title>\r\n"
				+ "    <link rel=\"shortcut icon\" type=\"image/png\" href=\"assets/img/team/logo.png\" />\r\n"
				+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" />\r\n"
				+ "    <meta content=\"\" name=\"description\" />\r\n" + "    <meta content=\"\" name=\"author\" />");
		out.println(" <link href=\"assets/plugins/pace/pace-theme-flash.css\" rel=\"stylesheet\" type=\"text/css\"\r\n"
				+ "        media=\"screen\" />\r\n"
				+ "    <link href=\"assets/plugins/boostrapv3/css/bootstrap.min.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n"
				+ "    <link href=\"assets/plugins/boostrapv3/css/bootstrap-theme.min.css\" rel=\"stylesheet\"\r\n"
				+ "        type=\"text/css\" />\r\n"
				+ "    <link href=\"assets/plugins/font-awesome/css/font-awesome.min.css\" rel=\"stylesheet\"\r\n"
				+ "        type=\"text/css\" />");
		out.println(" <style type=\"text/css\">\r\n" + "    body{\r\n" + "	margin:0;\r\n" + "	color:#6a6f8c;\r\n"
				+ "	background:white;\r\n" + "	font:600 16px/18px 'Open Sans',sans-serif;\r\n" + "}\r\n" + "\r\n"
				+ ".hr{\r\n" + "	height:2px;\r\n" + "	margin:60px 0 50px 0;\r\n"
				+ "	background:rgba(255,255,255,.2);\r\n" + "}\r\n" + ".foot-lnk{\r\n" + "	text-align:center;\r\n"
				+ "}\r\n" + "hr{\r\n" + "	display: block;\r\n" + "	 border-style: inset;\r\n"
				+ "  	border-width: 0.75px;\r\n" + "}\r\n" + "\r\n" + "</style>");
		out.println("</head>");
		out.println("<body bgcolor=white>");
		out.println("<div class=\"main-wrapper\">\r\n"
				+ "        <div role=\"navigation\" class=\"navbar navbar-default navbar-static-top\">\r\n"
				+ "            <div class=\"container\">\r\n" + "                <div class=\"compressed\">\r\n"
				+ "                    <div class=\"navbar-header\">"
				+ "<a href=\"index.jsp\" class=\"navbar-brand\">\r\n"
				+ "		 <img src=\"assets/img/team/logo@2x.png\" data-src=\"assets/img/team/logo@2x.png\" data-src-retina=\"assets/img/logo_2x.png\" \r\n"
				+ "					width=\"50\" height=\"40\" alt=\"logo\" /><b>Eco-Insurance</b></a> ");
		out.println("  <div class=\"main-wrapper\">\r\n"
				+ "        <div role=\"navigation\" class=\"navbar navbar-default navbar-static-top\">\r\n"
				+ "            <div class=\"container\">\r\n" + "                <div class=\"compressed\">\r\n"
				+ "                    <div class=\"navbar-header\">\r\n" + "                    </div>\r\n"
				+ "                    <div class=\"navbar-collapse collapse\">\r\n"
				+ "                        <ul class=\"nav navbar-nav navbar-right\">\r\n"
				+ "                            <li><a href=\"index.jsp\">Home</a></li>\r\n"
				+ "							<li><a href=\"Login.jsp\">My Account</a></li>\r\n"
				+ "                            <li><a href=\"contact.jsp\">Contact</a></li>\r\n"
				+ "                            \r\n" + "                        </ul>\r\n"
				+ "                    </div>\r\n" + "                    <!--/.nav-collapse -->\r\n"
				+ "					</div>\r\n" + "				</div>\r\n" + "			</div>\r\n"
				+ "			</div>");
		out.println("<h3><center>Welcome</h3><hr>");

		out.println("<h3>For Renewing the policy firstly check your details and click on Pay button</h3>");
		out.println("<table border=1>");
		out.println("<tr>");
		out.println("<th>Mobile No</th><th>User Name</th><th>First Name</th><th>Last Name</th><th>Email</th><th>Country</th><th>Address</th><th>Aadhar</th><th>Pan</th><th>Policy</th>");
		out.println("</tr>");
		
		try {

			st = con.createStatement();

			rs = st.executeQuery("select id,name,fname,lname,email,country,address,aadhar,pan,policy from users");

			while (rs.next()) {
				out.println("<tr><td>");
				out.println(rs.getString(1));
				out.println("<td>");
				out.println(rs.getString(2));
				out.println("<td>");
				out.println(rs.getString(3));
				out.println("<td>");
				out.println(rs.getString(4));
				out.println("<td>");
				out.println(rs.getString(5));
				out.println("<td>");
				out.println(rs.getString(6));
				out.println("<td>");
				out.println(rs.getString(7));
				out.println("<td>");
				out.println(rs.getString(8));
				out.println("<td>");
				out.println(rs.getString(9));
				out.println("<td>");
				out.println(rs.getString(10));
				out.println("</tr>");
			}
		} catch (Exception ae) {
			ae.printStackTrace();
		}
		
		out.println("</table><br><br>");
		out.println("<div>\r\n" + "	<a class=\"btn btn-info\" href=\"checkout.jsp\" target=\"_self\">Pay\r\n"
				+ "			</a>\r\n" + "</div>");
		out.println("<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>");
		out.println("<div class=\"section white footer\">\r\n" + 
				"		<div class=\"container\">\r\n" + 
				"			<div class=\"p-t-30 p-b-50\">\r\n" + 
				"				<div class=\"row\">\r\n" + 
				"					<div class=\"col-md-2 col-lg-2 col-sm-2 col-xs-12 xs-m-b-20\">\r\n" + 
				"						<img src=\"assets/img/team/logo@2x.png\"\r\n" + 
				"							data-src=\"assets/img/team/logo@2x.png\"\r\n" + 
				"							data-src-retina=\"assets/img/logo_2x.png\" width=\"45\" height=\"35\"\r\n" + 
				"							alt=\"logo\" /><b></b></a> <br /> <br /> � Eco-Insurance. <br />\r\n" + 
				"						All Rights Reserved.\r\n" + 
				"					</div>\r\n" + 
				"					<div class=\"col-md-4 col-lg-3 col-sm-4  col-xs-12 xs-m-b-20\">\r\n" + 
				"						<address\r\n" + 
				"							class=\"xs-no-padding  col-md-6 col-lg-6 col-sm-6  col-xs-12\">\r\n" + 
				"							Block-B<br> Fusion Square,<br>Noida,Uttar\r\n" + 
				"							Pradesh-201313\r\n" + 
				"						</address>\r\n" + 
				"\r\n" + 
				"						<div class=\"clearfix\"></div>\r\n" + 
				"					</div>\r\n" + 
				"					<div class=\"col-md-2 col-lg-2 col-sm-2  col-xs-12 xs-m-b-20\">\r\n" + 
				"\r\n" + 
				"					</div>\r\n" + 
				"					<div class=\"col-md-2 col-lg-2 col-sm-2  col-xs-12 \">\r\n" + 
				"						<div class=\"bold\">FOLLOW US</div>\r\n" + 
				"						<br /> <a href=\"https://www.facebook.com\"><i\r\n" + 
				"							class=\"fa fa-facebook fa-2x\"></i></a>&nbsp; <a\r\n" + 
				"							href=\"https://www.twitter.com\"> <i\r\n" + 
				"							class=\"fa fa-twitter fa-2x\"></i>\r\n" + 
				"						</a>&nbsp; <a href=\"https://www.youtube.com:\"><i\r\n" + 
				"							class=\"fa fa-youtube-play  fa-2x\"> </i></a>&nbsp; <a\r\n" + 
				"							href=\"https://www.pinterest.com\"> <i\r\n" + 
				"							class=\"fa fa-pinterest fa-2x\"></i></a>\r\n" + 
				"					</div>\r\n" + 
				"				</div>\r\n" + 
				"			</div>\r\n" + 
				"		</div>\r\n" + 
				"	</div>\r\n" + 
				"");
		out.println("</body>");
		out.println("</html>");
	}

	public void destroy() {
		System.out.println("this is destroy");
	}

}
