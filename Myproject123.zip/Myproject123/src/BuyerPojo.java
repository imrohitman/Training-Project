
public class BuyerPojo {
String name,lstname,add,city,zip,usernm,mob,email,adhr,pan,policy;

public String getName() {
	return name;
}

public String getLstname() {
	return lstname;
}

public String getAdd() {
	return add;
}

public String getCity() {
	return city;
}

public String getZip() {
	return zip;
}

public String getMob() {
	return mob;
}

public String getEmail() {
	return email;
}

public String getAdhr() {
	return adhr;
}

public String getPan() {
	return pan;
}

public String getPolicy() {
	return policy;
}

public void setName(String name) {
	this.name = name;
}

public void setLstname(String lstname) {
	this.lstname = lstname;
}

public void setAdd(String add) {
	this.add = add;
}

public void setCity(String city) {
	this.city = city;
}

public void setZip(String zip) {
	this.zip = zip;
}

public void setMob(String mob) {
	this.mob = mob;
}

public void setEmail(String email) {
	this.email = email;
}

public void setAdhr(String adhr) {
	this.adhr = adhr;
}

public void setPan(String pan) {
	this.pan = pan;
}

public void setPolicy(String policy) {
	this.policy = policy;
}

public String getUsernm() {
	return usernm;
}

public void setUsernm(String usernm) {
	this.usernm = usernm;
}

}
